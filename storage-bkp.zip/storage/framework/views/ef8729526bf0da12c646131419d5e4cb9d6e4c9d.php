<?php $__env->startSection('page-head'); ?>
    <?php echo $__env->make('includes.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('page-css'); ?>

    <style>
    .team-box {
        background-color: #152430;
        padding-bottom: 0.5rem;
    }.team-box .heading-guards {
         color: #fff;
        margin-top: 1rem;
        margin-bottom: 1rem;
     }
    .team-box a{
        font-weight: bold;
        color: #0E1F2F;
    }
        .team-box .card{
            padding: 1rem;
        }
    </style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('navigation'); ?>
    <?php echo $__env->make('includes.navigation', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('page-body'); ?>
    <main >
        <div class="hero ">
            <video  autoplay loop muted playsinline  poster="<?php echo e(asset('images/hero1.jpg')); ?>"  class="home-video">
                <source src="<?php echo e(asset('video/home.mp4')); ?>" type="video/mp4">
            </video>
            <div ><a class="btn-guards white-text modal-trigger" href="#modal1" >discover</a></div>
            <!-- Modal Structure -->
            <div>
                <a href="#target-element" id="scroll-to" class="scroll-to center white-text">
                    <div>scroll</div><img src="<?php echo e(asset('images/scroll-arrow.png')); ?>">
                </a>
            </div>
        </div>
        <div class="container" id="target-element">
            <div class="v-widget row">
                <div class="col l8 m6 s12 val-info">
                    <img src="<?php echo e(asset('images/houseIcon.svg')); ?>" class="responsive-img">
                    <span><span  class="v-widget-hd">Free property valuation</span><br/>
                <span class="v-widget-txt">Book a virtual appraisal for your property today</span>
            </span>
                </div>
                <div class="col l4 m6 s12 btn-container"> <a class="btn-guards modal-trigger" data-target="modal1" href="#modal1" >Book valuation</a></div>
            </div>
            <?php if(!empty($saleproperties)): ?>
            <div class="grid grid-1">
                <?php if(isset($saleproperties[0])): ?>
                <div class="item-1 slide-in-box">
                    <img src="<?php echo e($saleproperties[0]['img_600x1200']); ?>" alt="<?php echo e($saleproperties[0]['title']); ?>" class="responsive-img">
                    <a class="card-hover"  href="<?php echo e(route('website-property-detail',['property'=>$saleproperties[0]['id'],'slug'=>\Illuminate\Support\Str::slug($saleproperties[0]['title'])])); ?>">
                        <div class="content">
                            <h3 ><?php echo e($saleproperties[0]['title']); ?></h3>
                            <p><?php echo e($saleproperties[0]['summary']); ?></p>
                            <span class="btn-guards white-text">view more</span>
                        </div>
                    </a>
                </div>
                <?php endif; ?>
                <?php if(isset($saleproperties[1])): ?>
                <div class="item-2 slide-in-box">
                    <img src="<?php echo e($saleproperties[1]['img_1200x600']); ?>" alt="<?php echo e($saleproperties[1]['title']); ?>" class="responsive-img ">
                    <a class="card-hover"  href="<?php echo e(route('website-property-detail',['property'=>$saleproperties[1]['id'],'slug'=>\Illuminate\Support\Str::slug($saleproperties[1]['title'])])); ?>">
                        <div class="content">
                            <h3 ><?php echo e($saleproperties[1]['title']); ?></h3>
                            <p><?php echo e($saleproperties[1]['summary']); ?></p>
                            <span class="btn-guards white-text">view more</span>
                        </div>
                    </a>
                </div>
                <?php endif; ?>
                <?php if(isset($saleproperties[2])): ?>
                <div class="item-3 slide-in-box">
                    <img src="<?php echo e($saleproperties[2]['img_600x600']); ?>" alt="<?php echo e($saleproperties[2]['title']); ?>" class="responsive-img ">
                    <a class="card-hover"  href="<?php echo e(route('website-property-detail',['property'=>$saleproperties[2]['id'],'slug'=>\Illuminate\Support\Str::slug($saleproperties[2]['title'])])); ?>">
                        <div class="content">
                            <h3 ><?php echo e($saleproperties[2]['title']); ?></h3>
                            <p><?php echo e(Str::limit($saleproperties[2]['summary'],120,'...')); ?></p>
                            <span class="btn-guards white-text">view more</span>
                        </div>
                    </a>
                </div>
                <?php endif; ?>
                <div class="item-4 slide-in-box text-box" id="review-box-1">
                    <p>Loading...</p>
                </div>
            </div>
            <?php endif; ?>
            <?php if(!empty($lettingsproperties)): ?>
            <div class="grid grid-2">
                <div class="item-1 slide-in-box text-box"  id="review-box-2">
                    <p>Loading...</p>
                </div>
                <?php if(isset($lettingsproperties[0])): ?>
                <div class="item-2 slide-in-box ">
                    <img src="<?php echo e($lettingsproperties[0]['img_600x600']); ?>" alt="<?php echo e($lettingsproperties[0]['title']); ?>" class="responsive-img">
                    <a class="card-hover"  href="<?php echo e(route('website-property-detail',['property'=>$lettingsproperties[0]['id'],'slug'=>\Illuminate\Support\Str::slug($lettingsproperties[0]['title'])])); ?>">
                        <div class="content">
                            <h3 ><?php echo e($lettingsproperties[0]['title']); ?></h3>
                            <p><?php echo e(Str::limit($lettingsproperties[0]['summary'],150,'...')); ?></p>
                            <span class="btn-guards white-text">view more</span>
                        </div>
                    </a>
                </div>
                <?php endif; ?>
                <?php if(isset($lettingsproperties[1])): ?>
                <div class="item-3 slide-in-box ">
                    <img src="<?php echo e($lettingsproperties[1]['img_600x1200']); ?>" alt="<?php echo e($lettingsproperties[1]['title']); ?>" class="responsive-img">
                    <a class="card-hover"  href="<?php echo e(route('website-property-detail',['property'=>$lettingsproperties[1]['id'],'slug'=>\Illuminate\Support\Str::slug($lettingsproperties[1]['title'])])); ?>">
                        <div class="content">
                            <h3 ><?php echo e($lettingsproperties[1]['title']); ?></h3>
                            <p><?php echo e($lettingsproperties[1]['summary']); ?></p>
                            <span class="btn-guards white-text">view more</span>
                        </div>
                    </a>
                </div>
                <?php endif; ?>
                <?php if(isset($lettingsproperties[2])): ?>
                <div class="item-4 slide-in-box ">
                    <img src="<?php echo e($lettingsproperties[2]['img_1200x600']); ?>" alt="<?php echo e($lettingsproperties[2]['title']); ?>" class="responsive-img">
                    <a class="card-hover"  href="<?php echo e(route('website-property-detail',['property'=>$lettingsproperties[2]['id'],'slug'=>\Illuminate\Support\Str::slug($lettingsproperties[2]['title'])])); ?>">
                        <div class="content">
                            <h3 ><?php echo e($lettingsproperties[2]['title']); ?></h3>
                            <p><?php echo e($lettingsproperties[2]['summary']); ?></p>
                            <span class="btn-guards white-text">view more</span>
                        </div>
                    </a>
                </div>
                <?php endif; ?>

            </div>
            <?php endif; ?>
            <div class="center-align more-container"><a class="btn-guards" href="<?php echo e(route('website-property-search')); ?>?list=L">View All</a></div>
































            <div class="grid-6-col">
                <a href="http://www.guardsrealestate.com/"><img class="responsive-img" src="<?php echo e(asset('images/prs.png')); ?>"></a>
                <a href="http://www.guardsrealestate.com/"><img class="responsive-img" src="<?php echo e(asset('images/zoopla.png')); ?>"></a>
                <a href="http://www.guardsrealestate.com/"><img class="responsive-img" src="<?php echo e(asset('images/myDeposits.png')); ?>"></a>
                <a href="http://www.guardsrealestate.com/"><img class="responsive-img" src="<?php echo e(asset('images/prime.png')); ?>"></a>
                <a href="http://www.guardsrealestate.com/"><img class="responsive-img" src="<?php echo e(asset('images/protected.png')); ?>"></a>
                <a href="http://www.guardsrealestate.com/"><img class="responsive-img img-bw" src="<?php echo e(asset('images/onthemarket.jpeg')); ?>"></a>
            </div>
        </div>
        <div id="map"></div>

    </main>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('page-js'); ?>
    <script async defer
            src="https://maps.googleapis.com/maps/api/js?place_id=ChIJQWTBZCkFdkgRhGer0CEJ8cA&libraries=places&key=<?php echo e(GMAPS_KEY); ?>&callback=initMap">
    </script>
    <script>
        let reviews=null,currentReview=0;
        function initMap() {
        const map = new google.maps.Map(document.getElementById("map"), {
            center: { lat: -33.866, lng: 151.196 },
            zoom: 15
        });
        function setReview(rev_id,is_first) {
            let review = reviews[rev_id];
            let reviewbox =  document.getElementById('review-box-1');
            if(is_first === true)
            {
                let reviewbox_second =  document.getElementById('review-box-2');
                let review_second = reviews[rev_id+1];
                reviewbox_second.innerHTML = "<div><div class='reviewer'><img src='"
                    +review_second.profile_photo_url
                    +"' /> <a href='"
                    +review_second.author_url
                    +"' target='_blank'>"
                    +review_second.author_name
                    +"</a></div>"
                    +review_second.text.slice(0,200)+' ...'
                    +"</div>";

            }
            else
            {
                $r = getRandomReviewBox();
                reviewbox =  document.getElementById('review-box-'+$r);
                $('#review-box-'+$r).hide().fadeIn('slow');
            }

            reviewbox.innerHTML = "<div><div class='reviewer'><img src='"
                +review.profile_photo_url
                +"' /> <a href='"
                +review.author_url
                +"' target='_blank'>"
                +review.author_name
                +"</a></div>"
                +review.text.slice(0,200)+' ...'
                +"</div>";

        }
        const request = {
            placeId: "ChIJQWTBZCkFdkgRhGer0CEJ8cA",
            fields: ["reviews"]
        };

            const service = new google.maps.places.PlacesService(map);
            service.getDetails(request, (place, status) => {
                if (status === google.maps.places.PlacesServiceStatus.OK) {
                    reviews = place.reviews;
                    setReview(currentReview, true);
                    setInterval(function(){
                        if(currentReview == 4){
                            currentReview=-1;
                        }
                        currentReview++;
                        setReview(currentReview, false);
                    },3000 )

                }
            });
        }
        function getRandomReviewBox() {
            $n = Math.floor(Math.random() >= 0.5) +1;
            console.log($n);
            return $n;
        }
    </script>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('footer'); ?>
    <?php echo $__env->make('includes.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/guardsrealestate.com/releases/20210609011701/resources/views/pages/home.blade.php ENDPATH**/ ?>