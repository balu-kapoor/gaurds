<?php echo e($slot); ?>

<?php /**PATH /var/www/guardsrealestate.com/releases/20210609011701/vendor/laravel/framework/src/Illuminate/Mail/resources/views/text/footer.blade.php ENDPATH**/ ?>