<footer  class="page-footer">
    <div class="container">
        <div class="row">
            <div class="col m3 s6 social-block left-align">
                <div><img src="<?php echo e(asset('images/full_logo.png')); ?>" ></div>
                <p >Protecting your life investments</p>
                <div class="row icons">
                    <a class="col s3" href="https://www.facebook.com/GuardsRealEstate/"><i class="fa fa-facebook fa-fw"></i></a>
                    <a class="col s3" href="https://uk.linkedin.com/company/guardsrealestate"><i class="fa fa-linkedin fa-fw"></i></a>
                    <a class="col s3" href="https://twitter.com/guardsrealestat"><i class="fa fa-twitter fa-fw"></i></a>
                    <a class="col s3" href="https://www.instagram.com/guardsrealestate/"><i class="fa fa-instagram fa-fw"></i></a>
                </div>
            </div>
            <div class="col offset-m2 m3 s6 nav-links">
                <h5 class="amber-text text-darken-1">Navigation</h5>
                <ul>
                    <li><a href="<?php echo e(route('website-property-search')); ?>?list=L">Lettings</a></li>
                    <li><a href="<?php echo e(route('website-property-search')); ?>?list=S">Sales</a></li>
                    <li><a href="<?php echo e(route('website-about')); ?>">About Us</a></li>
                    <li><a href="<?php echo e(route('website-contact')); ?>">Get in touch</a></li>
                    <li><a  href="/payments">Payments</a></li>
                    <li><a  href="<?php echo e(route('website-fees')); ?>">Fees & Terms</a></li>
                    <li><a href="/privacy">Privacy Policy</a></li>
                    <li><a href="<?php echo e(route('website-certificates')); ?>" >Certificates</a></li>
                </ul>
            </div>
            <div class="col m4 s12 contact">
                <h5 class="amber-text text-darken-1">Contact</h5>
                <p>43 BERKELEY SQUARE<br>
                    LONDON<br>
                    W1J 5AP<br>
                    <br>
                    <strong>T</strong>
                    <a href="tel:+442036331271">+44 (0) 20 3633 1271</a>
                </p>
            </div>
        </div>
    </div>
</footer>
<div id="modal1" class="modal home-modal">

    <a class="modal-close white-text home-modal-close" href="#!"><i class="material-icons">close</i></a>
    <div class="modal-content home-modal-content home-first-modal-content">
        <div class="row adv-search home-page-modal-row">
            <div class="col s12">
                <ul class="tabs">
                    <li class="tab col s4 tab-one"><a class="active" href="#valuation-form">Valuation</a></li>
                    <li class="tab col s4 tab-two"><a  href="#lettings-form">To Let</a></li>
                    <li class="tab col s4 tab-three"><a href="#sales-form">For Sale</a></li>
                </ul>
            </div>

            <div id="valuation-form" class="col s12 tab-content">
                <form id="book-valuation-form-el">
                    <div class="row">
                        <div class="col s12 m6">
                            <div class="search-wrapper">
                                <div class="input-field">
                                    <input name="postcode" required type="text"  class="autocomplete" placeholder="PostCode">
                                </div>
                            </div>
                        </div>

                        <div class="col s12 m6">


                            <div class="input-field">
                                <div class="num-ip">
                                    <span>Bedrooms</span>
                                    <div class="number-ip-field">
                                        <input name="bedrooms" required type="number" placeholder="+1" min="0" max="10" step="1" value="1">
                                        <div class="num-nav">
                                            <div class="num-button num-up">+</div>
                                            <div class="num-button num-down">-</div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col s12 m6">
                            <div class="search-wrapper">
                                <div class="input-field">
                                    <input name="name" required type="text" placeholder="First Name">
                                </div>
                            </div>
                        </div>
                        <div class="col s12 m6">

                            <div class="search-wrapper">
                                <div class="input-field">
                                    <input name="email" required type="email" placeholder="Email">
                                </div>
                            </div>
                        </div>
                        <div class="col s12 m6">

                            <div class="search-wrapper">
                                <div class="input-field">
                                    <input name="phone" required type="text" placeholder="Phone Number">
                                </div>
                            </div>
                        </div>
                        <div class="col s12 m6">
                            <button type="submit" id="bookvaluation-button-submit-container" class="btn-guards home-modal-wrapper">Book Valuation</button>

                            <div id="bookvaluation-success-msg">Thankyou for contacting us. One of our representatives will get back to you shortly.</div>
                            <div id="bookvaluation-error-msg">Oops! There was an error with your request. Please try again later.</div>
                        </div>
                    </div>
                </form>
            </div>
            <div id="lettings-form" class="col s12 tab-content">
                <form action="<?php echo e(route('website-property-search')); ?>" method="get">
                    <input type="hidden" name="list" value="L">
                <div class="col s12">
                    <div class="search-wrapper">
                        <div class="input-field">
                            <input type="text" name="postcode" id="autocomplete-location" class="autocomplete rent" placeholder="Location">
                            <i class="material-icons">search</i>
                        </div>
                    </div>
                </div>

                <div class="col s12 m6">
                    <div class="input-field">
                        <select name="type">
                            <option value="" disabled selected>Property Type</option>
                            <?php $__currentLoopData = $filterOptions['rent']['property_type_list']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $type): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option><?php echo e($type); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                </div>
                <div class="col s12 m6">
                    <div class="input-field">
                        <select name="pricerange">
                            <option value="" disabled selected>Price</option>
                            <?php $__currentLoopData = $filterOptions['rent']['price_bracket_list']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pricebracket): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($pricebracket['min']); ?>|<?php echo e($pricebracket['max']); ?>">&#163; <?php echo e($pricebracket['min']); ?> - &#163; <?php echo e($pricebracket['max']); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                </div>
                <div class="col s12 m6">

                    <div class="input-field">
                        <div class="num-ip">
                            <span>Bedrooms</span>
                            <div class="number-ip-field">
                                <input name="beds" type="number" placeholder="+1" min="0" max="10" step="1" value="1">
                                <div class="num-nav">
                                    <div class="num-button num-up">+</div>
                                    <div class="num-button num-down">-</div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col s12 m6 btn-find-wrapper ">

                    <button type="submit" class="btn-guards home-modal-wrapper">Search</button>
                </div>
                <!--<div class="col s12">
                    <div class="input-field">
                        <p class="p-m-text advance-row-button">
                            Advanced &nbsp; <span><i class="fa fa-ellipsis-v" aria-hidden="true"></i></span>
                        </p>
                    </div>
                </div>-->
                </form>
            </div>

            <div id="sales-form" class="col s12 tab-content">
                <form action="<?php echo e(route('website-property-search')); ?>" method="get">
                    <input type="hidden" name="list" value="S">
                <div class="col s12">
                    <div class="search-wrapper">
                        <div class="input-field">
                            <input type="text" name="postcode"  class="autocomplete buy" placeholder="Location">
                            <i class="material-icons">search</i>
                        </div>
                    </div>
                </div>

                <div class="col s12 m6">
                    <div class="input-field">
                        <select name="type">
                            <option value="" disabled selected>Property Type</option>
                            <?php $__currentLoopData = $filterOptions['buy']['property_type_list']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $type): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option><?php echo e($type); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                </div>
                <div class="col s12 m6">
                    <div class="input-field">
                        <select name="pricerange">
                            <option value="" disabled selected>Price</option>
                            <?php $__currentLoopData = $filterOptions['buy']['price_bracket_list']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pricebracket): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($pricebracket['min']); ?>|<?php echo e($pricebracket['max']); ?>">&#163; <?php echo e($pricebracket['min']); ?> - &#163; <?php echo e($pricebracket['max']); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                </div>
                <div class="col s12 m6">

                    <div class="input-field">
                        <div class="num-ip">
                            <span>Bedrooms</span>
                            <div class="number-ip-field">
                                <input name="beds"  type="number" placeholder="+1" min="0" max="10" step="1" value="1">
                                <div class="num-nav">
                                    <div class="num-button num-up">+</div>
                                    <div class="num-button num-down">-</div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col s12 m6 btn-find-wrapper">

                    <button type="submit" class="btn-guards home-modal-wrapper">Search</button>
                </div>
                <!--<div class="col s12">
                    <div class="input-field">
                        <p class="p-m-text advance-row-button">
                            Advanced &nbsp; <span><i class="fa fa-ellipsis-v" aria-hidden="true"></i></span>
                        </p>
                    </div>
                </div>-->
                </form>
            </div>
        </div>

    </div>
    <!--<div class="modal-content home-modal-content home-second-modal-content">

        <div class="row srch-am ameneties-section">
            <span class="search-hd col s12">Ameneties</span>
            <div class="col s6 m4">
                <label>
                    <input type="checkbox" class="filled-in" />
                    <span>Air Conditioning</span>
                </label>
            </div>
            <div class="col s6 m4">
                <label>
                    <input type="checkbox" class="filled-in" />
                    <span>Wifi</span>
                </label>
            </div>
            <div class="col s6 m4">
                <label>
                    <input type="checkbox" class="filled-in" />
                    <span>Barbeque</span>
                </label>
            </div>
            <div class="col s6 m4">
                <label>
                    <input type="checkbox" class="filled-in" />
                    <span>Sauna</span>
                </label>
            </div>
            <div class="col s6 m4">
                <label>
                    <input type="checkbox" class="filled-in" />
                    <span>Gym</span>
                </label>
            </div>
            <div class="col s6 m4">
                <label>
                    <input type="checkbox" class="filled-in" />
                    <span>Dryer</span>
                </label>
            </div>
            <div class="col s6 m4">
                <label>
                    <input type="checkbox" class="filled-in" />
                    <span>TV</span>
                </label>
            </div>
            <div class="col s6 m4">
                <label>
                    <input type="checkbox" class="filled-in" />
                    <span>Washer</span>
                </label>
            </div>
            <div class="col s6 m4">
                <label>
                    <input type="checkbox" class="filled-in" />
                    <span>Lawn</span>
                </label>
            </div>
            <div class="col s6 m4">
                <label>
                    <input type="checkbox" class="filled-in" />
                    <span>Refrigerator</span>
                </label>
            </div>
            <div class="col s12 m12">
                <label>
                    <input type="checkbox" class="filled-in" />
                    <span>Pool</span>
                </label>
            </div>

        </div>
    </div>-->
</div>
<?php /**PATH /var/www/guardsrealestate.com/releases/20210609011701/resources/views/includes/footer.blade.php ENDPATH**/ ?>