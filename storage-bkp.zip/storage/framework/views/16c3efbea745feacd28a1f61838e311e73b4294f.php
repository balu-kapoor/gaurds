<<MIXEDSTATUS>>
|||||| <<DISPLAYADDRESS>>
|||||| <<PROPTYPE>>
|||||| <<PRICE>>
|||||| [<span id="ResidentialPropertyDetailsTags.NumberBeds" class="documenttag">[Residential Property Details Tags - NumberBeds]</span>]
|||||| [<span id="ResidentialPropertyDetailsTags.NumberBathrooms" class="documenttag">[Residential Property Details Tags - NumberBathrooms]</span>]
|||||| [<span id="ResidentialPropertyDetailsTags.NumberReceptions" class="documenttag">[Residential Property Details Tags - Number Receptions]</span>]
|||||| <<BEDSWITHTYPE>>
|||||| <<SUMMARY>>
|||||| <a class="detlink" href="[<span id="PropertyTags.WebsiteURLHref" class="documenttag">[Property Tags - WebsiteURLHref]</span>]">PROPERTY DETAILS</a>
|||||| [<span id="PropertyTags.DisplayArea" class="documenttag">[Property Tags - Floor Area]</span>]
|||||| [<span id="PropertyTags.FeatureListWithCommas" class="documenttag" >[Property Tags - Features]</span>]
|||||| [<span id="PropertyTags.Reference" class="documenttag">[Property Tags - Reference]</span>]
|||||| [<span id="PropertyTags.IntelligentFloorplanDisplay" title="OutputDimensions=true|height=150|showPlaceholderIfNull=true" class="documenttag">[Property Tags - Intelligent Floorplan Display]</span>]
|||||| [<span id="PropertyTags.EPC" class="documenttag">[Property Tags - EPC]</span>]
|||||| [<span id="PropertyTags.Address" class="documenttag">[Property Tags - Full Address]</span>]
|||||| [<span id="PropertyTags.Town" class="documenttag">[Property Tags - Town]</span>]
|||||| [<span id="PropertyTags.Postcode" class="documenttag">[Property Tags - Postcode]</span>]
|||||| [<span id="PropertyTags.Latitude" class="documenttag">[Property Tags - Latitude]</span>]
|||||| [<span id="PropertyTags.Longitude" class="documenttag">[Property Tags - Longitude]</span>]
|||||| [<span id="PropertyTags.DisclaimerText" class="documenttag">[Property Tags - DisclaimerText]</span>]
|||||| [<span id="PropertyTags.Price" class="documenttag">[Property Tags - Price]</span>]
|||||| [<span id="PropertyTags.PriceQualifier" class="documenttag">[Property Tags - PriceQualifier]</span>]
|||||| [<span id="PropertyTags.VirtualTourLink" class="documenttag">[Property Tags - VirtualTourLink]</span>]
|||||| <<PHOTOLINK>>
|||||| [<span id="PropertyTags.PhotoList" class="documenttag" title="listStart=1|cropToFill=' . $photoCrop . '|width=' . $photoWidth . '|height=' . $photoHeight . '|outputDimensions=false">[Property Tags - PhotoList]</span>]
<|PROPERTY_TAG|><?php /**PATH /var/www/guardsrealestate.com/releases/20210609011701/resources/views/components/10ninetyPropertyJson.blade.php ENDPATH**/ ?>